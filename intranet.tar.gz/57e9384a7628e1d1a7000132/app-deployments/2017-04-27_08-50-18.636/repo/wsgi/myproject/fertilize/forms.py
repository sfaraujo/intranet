#!/usr/bin/python

from django import forms
from django.forms import ModelForm

		

        

""""
class fieldNeedProductsQtForm(ModelForm):
    class Meta:
        model = FieldNeedProductsQt
        exclude = ('',)
        
        """