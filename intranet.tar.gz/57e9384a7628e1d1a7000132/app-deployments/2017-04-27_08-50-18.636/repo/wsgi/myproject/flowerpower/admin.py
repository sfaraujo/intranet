from django.contrib import admin
from .models import *

admin.site.register(ParrotAuth)
admin.site.register(Location)
admin.site.register(Sample)
admin.site.register(Evapotranspiration)
admin.site.register(Sensor)
